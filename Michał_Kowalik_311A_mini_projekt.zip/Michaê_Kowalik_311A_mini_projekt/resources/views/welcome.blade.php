@extends('layouts.app')

@section('content')
<div class="container">
    <div class="h1 alert alert-info">
        Zaloguj się lub utwórz konto aby kontynuować.
    </div>
</div>
@endsection
